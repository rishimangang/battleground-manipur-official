# Battleground Manipur — Unity Starter

Player: RISHI

This starter contains the Unity project folders needed to begin:
- Assets/
- ProjectSettings/
- Packages/

Android application ID:
`com.rishimangang.battlegroundmanipur`

Open the project with Unity 6 (6000.0.43f1) or adjust ProjectVersion.txt to your installed Unity version.
